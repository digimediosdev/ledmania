import React, { useState, useEffect, useRef } from 'react';
import { Search, ShoppingCart, User, Menu, X, Zap, MessageSquare, ChevronDown, Phone, Mail, MapPin, Facebook, Instagram, Youtube, ArrowRight, Square, RectangleHorizontal, Sun, Factory, Circle, Lamp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PRODUCTS, CATEGORIES, IP_RATINGS } from './constants';
import { Product, FilterState } from './types';

const TopBar = () => (
  <div className="bg-gray-100 text-tech-gray text-[10px] py-2 border-b border-gray-200 hidden sm:block">
    <div className="max-w-7xl mx-auto px-4 flex justify-between items-center font-bold uppercase tracking-widest">
      <div className="flex gap-6">
        <div className="flex items-center gap-1">
          <Phone size={12} className="text-forest-green" />
          <span>+56 2 2345 6789</span>
        </div>
        <div className="flex items-center gap-1">
          <Mail size={12} className="text-forest-green" />
          <span>ventas@ledmania.cl</span>
        </div>
      </div>
      <div className="flex gap-4 items-center">
        <a href="#" className="hover:text-forest-green transition-colors"><Facebook size={14} /></a>
        <a href="#" className="hover:text-forest-green transition-colors"><Instagram size={14} /></a>
        <a href="#" className="hover:text-forest-green transition-colors"><Youtube size={14} /></a>
        <span className="h-3 w-[1px] bg-gray-300 mx-2" />
        <div className="flex items-center gap-1">
          <MapPin size={12} className="text-forest-green" />
          <span>Santiago, Chile</span>
        </div>
      </div>
    </div>
  </div>
);

const Navbar = ({ onSelectCategory, onGoHome }: { onSelectCategory: (cat: string) => void, onGoHome: () => void }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-50 shadow-sm">
      <TopBar />
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-8">
          <div className="flex items-center gap-2 flex-shrink-0 cursor-pointer" onClick={onGoHome}>
            <Zap className="text-bright-yellow w-8 h-8 fill-bright-yellow" />
            <span className="text-2xl font-black tracking-tighter italic text-forest-green">LEDMANIA</span>
          </div>

          <div className="hidden md:flex flex-grow max-w-2xl relative">
            <input 
              type="text" 
              placeholder="Buscar productos, categorías, especificaciones..." 
              className="w-full bg-gray-50 border border-gray-200 rounded-sm py-2 px-4 text-sm focus:outline-none focus:border-forest-green transition-colors"
            />
            <button className="absolute right-0 top-0 bottom-0 px-4 bg-forest-green text-white rounded-r-sm hover:bg-forest-green-light transition-colors">
              <Search size={18} />
            </button>
          </div>

          <div className="flex items-center gap-6">
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] font-bold text-tech-gray-light uppercase">Mi Cuenta</span>
              <button className="text-sm font-black text-tech-gray hover:text-forest-green transition-colors">Iniciar Sesión</button>
            </div>
            <button className="p-2 text-tech-gray hover:text-forest-green transition-colors relative">
              <ShoppingCart size={24} />
              <span className="absolute top-0 right-0 bg-bright-yellow text-black text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-white">2</span>
            </button>
            <button className="md:hidden p-2 text-tech-gray" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              <Menu size={28} />
            </button>
          </div>
        </div>
      </div>

      <nav className="bg-forest-green text-white hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex items-center">
          <div className="relative" ref={dropdownRef}>
            <button 
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-3 bg-forest-green-light px-6 py-3 font-black text-sm uppercase tracking-widest hover:bg-forest-green-light/80 transition-colors"
            >
              <Menu size={18} />
              Categorías
              <ChevronDown size={16} className={`transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {isDropdownOpen && (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full left-0 w-64 bg-white shadow-2xl border-t-2 border-bright-yellow py-2 z-[60]"
                >
                  {CATEGORIES.map(cat => {
                    const iconMap: { [key: string]: React.ElementType } = {
                      Square,
                      RectangleHorizontal,
                      Sun,
                      Factory,
                      Circle,
                      Lamp
                    };
                    const IconComponent = iconMap[cat.icon || 'Square'];
                    return (
                      <button 
                        key={cat.name} 
                        onClick={() => { onSelectCategory(cat.name); setIsDropdownOpen(false); }}
                        className="w-full text-left flex items-center gap-3 px-6 py-3 text-sm text-tech-gray hover:bg-gray-50 hover:text-forest-green transition-colors font-medium border-b border-gray-50 last:border-0"
                      >
                        {IconComponent && <IconComponent size={14} className="text-tech-gray-light" />}
                        {cat.name}
                      </button>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center space-x-8 ml-8 text-[11px] font-bold uppercase tracking-widest">
            <a href="#" className="hover:text-bright-yellow transition-colors">Ofertas</a>
            <a href="#" className="hover:text-bright-yellow transition-colors">Novedades</a>
            <a href="#" className="hover:text-bright-yellow transition-colors">Proyectos</a>
            <a href="#" className="hover:text-bright-yellow transition-colors">Blog Técnico</a>
            <a href="#" className="hover:text-bright-yellow transition-colors">Contacto</a>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            className="fixed inset-0 bg-white z-[100] md:hidden flex flex-col"
          >
            <div className="p-4 flex justify-between items-center border-b border-gray-100">
              <div className="flex items-center gap-2">
                <Zap className="text-bright-yellow w-6 h-6 fill-bright-yellow" />
                <span className="text-xl font-black tracking-tighter italic text-forest-green">LEDMANIA</span>
              </div>
              <button onClick={() => setIsMenuOpen(false)}><X size={28} /></button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto">
              <div className="space-y-4">
                <p className="text-xs font-black uppercase text-tech-gray-light tracking-widest">Categorías</p>
                {CATEGORIES.map(cat => {
                  const iconMap: { [key: string]: React.ElementType } = {
                    Square,
                    RectangleHorizontal,
                    Sun,
                    Factory,
                    Circle,
                    Lamp
                  };
                  const IconComponent = iconMap[cat.icon || 'Square'];
                  return (
                    <button 
                      key={cat.name} 
                      onClick={() => { onSelectCategory(cat.name); setIsMenuOpen(false); }}
                      className="flex items-center gap-4 w-full text-left text-lg font-bold text-tech-gray py-2"
                    >
                      {IconComponent && <IconComponent size={20} className="text-forest-green" />}
                      {cat.name}
                    </button>
                  );
                })}
              </div>
              <hr />
              <div className="space-y-4">
                <a href="#" className="block text-lg font-bold text-tech-gray">Ofertas</a>
                <a href="#" className="block text-lg font-bold text-tech-gray">Proyectos</a>
                <a href="#" className="block text-lg font-bold text-tech-gray">Contacto</a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

const Hero = () => (
  <section className="relative h-[400px] md:h-[500px] overflow-hidden bg-black">
    <div className="absolute inset-0">
      <img 
        src="https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&q=80&w=1920" 
        alt="Instalación LED" 
        className="w-full h-full object-cover opacity-60"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 to-transparent" />
    </div>
    
    <div className="relative max-w-7xl mx-auto px-4 h-full flex flex-col justify-center items-start">
      <motion.div 
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-2xl"
      >
        <div className="flex items-center gap-2 mb-4">
          <div className="h-[2px] w-12 bg-bright-yellow" />
          <span className="text-bright-yellow font-bold uppercase tracking-[0.3em] text-xs">Innovación en Iluminación</span>
        </div>
        <h1 className="text-4xl md:text-6xl font-black text-white leading-none mb-6 uppercase italic">
          Soluciones LED <br />
          <span className="text-bright-yellow">Eficiencia Inteligente</span>
        </h1>
        <p className="text-gray-300 text-base md:text-lg mb-8 max-w-lg font-light leading-relaxed">
          Iluminación profesional para proyectos industriales, comerciales y residenciales. 
          Diseñada para durar, optimizada para ahorrar.
        </p>
        <div className="flex gap-4">
          <button className="btn-yellow text-sm md:text-base px-6 md:px-8 py-3">Ver Catálogo</button>
          <button className="border border-white/30 text-white hover:bg-white/10 px-6 md:px-8 py-3 uppercase tracking-widest text-[10px] md:text-xs font-bold transition-all">Fichas Técnicas</button>
        </div>
      </motion.div>
    </div>
  </section>
);

const Sidebar = ({ 
  onSelectCategory, 
  filters, 
  onFilterChange,
  selectedCategory
}: { 
  onSelectCategory: (cat: string) => void,
  filters: FilterState,
  onFilterChange: (filters: FilterState) => void,
  selectedCategory: string | null
}) => {
  const iconMap: { [key: string]: React.ElementType } = {
    Square,
    RectangleHorizontal,
    Sun,
    Factory,
    Circle,
    Lamp
  };

  const toggleFilter = (key: keyof FilterState, value: string) => {
    const currentValues = filters[key] as string[];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    onFilterChange({ ...filters, [key]: newValues });
  };

  return (
    <aside className="w-64 flex-shrink-0 hidden lg:block">
      <div className="sticky top-40 space-y-8 max-h-[calc(100vh-10rem)] overflow-y-auto pr-4 custom-scrollbar">
        <div>
          <h3 className="text-xs font-black uppercase tracking-widest mb-4 flex items-center justify-between">
            Categorías
            <span className="h-[1px] flex-grow ml-4 bg-gray-200" />
          </h3>
          <ul className="space-y-2">
            {CATEGORIES.map(cat => {
              const IconComponent = iconMap[cat.icon || 'Square'];
              const isActive = selectedCategory === cat.name;
              return (
                <li 
                  key={cat.name} 
                  onClick={() => onSelectCategory(cat.name)} 
                  className={`flex items-center gap-3 group cursor-pointer p-1 rounded-sm transition-all ${isActive ? 'bg-forest-green/5' : ''}`}
                >
                  <div className={`w-8 h-8 rounded-sm flex items-center justify-center transition-colors ${isActive ? 'bg-forest-green text-white' : 'bg-gray-50 group-hover:bg-forest-green/10'}`}>
                    {IconComponent && <IconComponent size={14} className={isActive ? 'text-white' : 'text-tech-gray-light group-hover:text-forest-green transition-colors'} />}
                  </div>
                  <span className={`text-sm font-medium transition-colors ${isActive ? 'text-forest-green' : 'text-tech-gray-light group-hover:text-forest-green'}`}>
                    {cat.name}
                  </span>
                </li>
              );
            })}
          </ul>
        </div>

      {!selectedCategory ? (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="bg-tech-gray rounded-sm overflow-hidden relative group cursor-pointer"
          onClick={() => onSelectCategory('Lámparas')}
        >
          <img 
            src="https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&q=80&w=800" 
            alt="Promo" 
            className="w-full h-64 object-cover opacity-50 group-hover:scale-110 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 p-6 flex flex-col justify-end">
            <span className="bg-bright-yellow text-black text-[8px] font-black px-2 py-0.5 uppercase tracking-widest w-fit mb-2">Oferta</span>
            <h4 className="text-white font-black uppercase italic tracking-tighter text-xl leading-none mb-2">
              Lámparas <br />
              <span className="text-bright-yellow">40% OFF</span>
            </h4>
            <p className="text-white/70 text-[10px] leading-tight mb-4">Liquidación de temporada por tiempo limitado.</p>
            <div className="flex items-center gap-2 text-bright-yellow text-[10px] font-bold uppercase tracking-widest">
              Ver Ahora <ArrowRight size={12} />
            </div>
          </div>
        </motion.div>
      ) : (
        <>
          <div>
            <h3 className="text-xs font-black uppercase tracking-widest mb-4 flex items-center justify-between">
              Filtros Técnicos
              <span className="h-[1px] flex-grow ml-4 bg-gray-200" />
            </h3>
            
            <div className="space-y-6">
              <div className="space-y-3">
                <label className="tech-label">Potencia (W)</label>
                <div className="grid grid-cols-2 gap-2">
                  <input 
                    type="number" 
                    placeholder="Min" 
                    value={filters.wattage[0]}
                    onChange={(e) => onFilterChange({ ...filters, wattage: [Number(e.target.value), filters.wattage[1]] })}
                    className="border border-gray-200 p-1 text-xs focus:outline-none focus:border-forest-green" 
                  />
                  <input 
                    type="number" 
                    placeholder="Max" 
                    value={filters.wattage[1]}
                    onChange={(e) => onFilterChange({ ...filters, wattage: [filters.wattage[0], Number(e.target.value)] })}
                    className="border border-gray-200 p-1 text-xs focus:outline-none focus:border-forest-green" 
                  />
                </div>
              </div>

              <div className="space-y-3">
                <label className="tech-label">Color de Luz</label>
                <div className="flex flex-wrap gap-2">
                  {['Frío', 'Cálido', 'Neutro'].map(color => (
                    <button 
                      key={color} 
                      onClick={() => toggleFilter('lightColors', color)}
                      className={`px-2 py-1 border text-[10px] font-bold transition-all ${
                        filters.lightColors.includes(color) 
                          ? 'border-forest-green bg-forest-green text-white' 
                          : 'border-gray-200 hover:border-forest-green text-tech-gray-light'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="tech-label">Grado de Protección IP</label>
                <div className="flex flex-wrap gap-2">
                  {IP_RATINGS.map(ip => (
                    <button 
                      key={ip} 
                      onClick={() => toggleFilter('ipRatings', ip)}
                      className={`px-2 py-1 border text-[10px] font-bold transition-all ${
                        filters.ipRatings.includes(ip) 
                          ? 'border-forest-green bg-forest-green text-white' 
                          : 'border-gray-200 hover:border-forest-green text-tech-gray-light'
                      }`}
                    >
                      {ip}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="tech-label">Forma</label>
                <div className="flex flex-wrap gap-2">
                  {['Redondo', 'Cuadrado', 'Rectangular', 'Tubo', 'Campana', 'Bulbo'].map(shape => (
                    <button 
                      key={shape} 
                      onClick={() => toggleFilter('shapes', shape)}
                      className={`px-2 py-1 border text-[10px] font-bold transition-all ${
                        filters.shapes.includes(shape) 
                          ? 'border-forest-green bg-forest-green text-white' 
                          : 'border-gray-200 hover:border-forest-green text-tech-gray-light'
                      }`}
                    >
                      {shape}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="tech-label">Tamaño / Formato</label>
                <div className="flex flex-wrap gap-2">
                  {['A60', '300mm', '250x180mm', '60x60cm', '120cm', '22cm', '30x120cm', '30cm'].map(size => (
                    <button 
                      key={size} 
                      onClick={() => toggleFilter('sizes', size)}
                      className={`px-2 py-1 border text-[10px] font-bold transition-all ${
                        filters.sizes.includes(size) 
                          ? 'border-forest-green bg-forest-green text-white' 
                          : 'border-gray-200 hover:border-forest-green text-tech-gray-light'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
          
          <button 
            onClick={() => onFilterChange({
              lumens: [0, 20000],
              wattage: [0, 1000],
              ipRatings: [],
              priceRange: [0, 1000000],
              lightColors: [],
              shapes: [],
              sizes: []
            })}
            className="w-full mt-4 py-2 text-[10px] font-black uppercase tracking-widest text-tech-gray-light hover:text-forest-green transition-colors border border-dashed border-gray-200"
          >
            Limpiar Filtros
          </button>
        </>
      )}

      <div className="bg-gray-50 p-4 border-l-2 border-bright-yellow mt-8">
        <p className="text-[10px] font-bold uppercase tracking-widest text-tech-gray mb-1">¿Necesitas Asesoría?</p>
        <p className="text-xs text-tech-gray-light">Nuestro equipo técnico está disponible para cálculos de iluminación personalizados.</p>
      </div>
    </div>
  </aside>
  );
};

const CategoryGrid = ({ onSelectCategory }: { onSelectCategory: (cat: string) => void }) => (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 py-12">
    {CATEGORIES.map((cat) => (
      <motion.div 
        key={cat.name}
        whileHover={{ scale: 1.02 }}
        onClick={() => onSelectCategory(cat.name)}
        className="relative h-64 overflow-hidden group cursor-pointer rounded-sm"
      >
        <img 
          src={cat.image} 
          alt={cat.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
        <div className="absolute bottom-6 left-6 right-6">
          <h3 className="text-2xl font-black text-white uppercase italic tracking-tighter mb-2">{cat.name}</h3>
          <div className="flex items-center gap-2 text-bright-yellow text-xs font-bold uppercase tracking-widest">
            Ver Productos <ArrowRight size={14} />
          </div>
        </div>
      </motion.div>
    ))}
  </div>
);

const ProductCard = ({ product }: { product: Product }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="bg-white border border-gray-100 group relative"
  >
    <div className="aspect-square overflow-hidden bg-gray-100 relative">
      <img 
        src={product.image} 
        alt={product.name} 
        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        referrerPolicy="no-referrer"
      />
      <div className="absolute top-2 left-2 flex flex-col gap-1">
        {product.isNew && <span className="bg-forest-green text-white text-[10px] font-bold px-2 py-0.5 uppercase">Nuevo</span>}
        {product.discount && <span className="badge-yellow">-{product.discount}% DCTO</span>}
      </div>
      <button className="absolute bottom-0 left-0 right-0 bg-forest-green text-white py-3 translate-y-full group-hover:translate-y-0 transition-transform duration-300 font-bold uppercase tracking-widest text-xs">
        Vista Rápida
      </button>
    </div>
    
    <div className="p-4">
      <div className="flex justify-between items-start mb-2">
        <span className="tech-label">{product.category}</span>
        <span className="font-mono text-xs font-bold text-forest-green">{product.ipRating}</span>
      </div>
      <h3 className="font-bold text-tech-gray group-hover:text-forest-green transition-colors mb-4 line-clamp-1">
        {product.name}
      </h3>
      
      <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b border-gray-50">
        <div className="flex flex-col">
          <span className="tech-label">Lumens</span>
          <span className="text-xs font-black text-bright-yellow-dark">{product.lumens} LM</span>
        </div>
        <div className="flex flex-col">
          <span className="tech-label">Potencia</span>
          <span className="text-xs font-black text-tech-gray">{product.wattage} W</span>
        </div>
        <div className="flex flex-col">
          <span className="tech-label">Color Luz</span>
          <span className="text-xs font-black text-tech-gray">{product.lightColor}</span>
        </div>
        {product.shape && (
          <div className="flex flex-col">
            <span className="tech-label">Forma</span>
            <span className="text-xs font-black text-tech-gray">{product.shape}</span>
          </div>
        )}
      </div>
      
      {product.size && (
        <div className="mb-4 flex items-center gap-2">
          <span className="tech-label">Tamaño:</span>
          <span className="text-[10px] font-bold bg-gray-100 px-2 py-0.5 rounded-full text-tech-gray">{product.size}</span>
        </div>
      )}
      
      <div className="flex items-center justify-between">
        <div className="flex flex-col">
          {product.oldPrice && (
            <span className="text-xs text-gray-400 line-through font-bold">${product.oldPrice.toLocaleString('es-CL')}</span>
          )}
          <span className="text-xl font-black text-tech-gray">${product.price.toLocaleString('es-CL')}</span>
        </div>
        <button className="p-2 bg-gray-100 hover:bg-bright-yellow transition-colors rounded-sm">
          <ShoppingCart size={18} />
        </button>
      </div>
    </div>
  </motion.div>
);

const AIChatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      <AnimatePresence>
        {!isOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="absolute bottom-16 right-0 bg-white shadow-2xl p-4 rounded-xl border border-gray-100 w-64 mb-2"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-forest-green rounded-full flex items-center justify-center flex-shrink-0">
                <Zap size={16} className="text-bright-yellow fill-bright-yellow" />
              </div>
              <div>
                <p className="text-[10px] font-black uppercase text-forest-green mb-1 tracking-widest">Asistente Técnico AI</p>
                <p className="text-xs text-tech-gray leading-relaxed">
                  Pregúntame sobre Lumens, compatibilidad o instalación técnica.
                </p>
              </div>
            </div>
            <div className="absolute -bottom-2 right-6 w-4 h-4 bg-white border-r border-b border-gray-100 rotate-45" />
          </motion.div>
        )}
      </AnimatePresence>
      
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-forest-green hover:bg-forest-green-light text-white rounded-full flex items-center justify-center shadow-2xl transition-all hover:scale-110 active:scale-95"
      >
        {isOpen ? <X size={24} /> : <MessageSquare size={24} />}
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-bright-yellow rounded-full animate-pulse" />
      </button>
    </div>
  );
};

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<string>('popular');
  const [filters, setFilters] = useState<FilterState>({
    lumens: [0, 20000],
    wattage: [0, 1000],
    ipRatings: [],
    priceRange: [0, 1000000],
    lightColors: [],
    shapes: [],
    sizes: []
  });

  const filteredProducts = PRODUCTS
    .filter(p => !selectedCategory || p.category === selectedCategory)
    .filter(p => p.wattage >= filters.wattage[0] && p.wattage <= filters.wattage[1])
    .filter(p => filters.ipRatings.length === 0 || filters.ipRatings.includes(p.ipRating))
    .filter(p => filters.lightColors.length === 0 || filters.lightColors.includes(p.lightColor))
    .filter(p => !p.shape || filters.shapes.length === 0 || filters.shapes.includes(p.shape))
    .filter(p => !p.size || filters.sizes.length === 0 || filters.sizes.includes(p.size))
    .sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'newest') return (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0);
      return 0;
    });

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Navbar onSelectCategory={setSelectedCategory} onGoHome={() => setSelectedCategory(null)} />
      <Hero />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col lg:flex-row gap-12">
          <Sidebar 
            onSelectCategory={setSelectedCategory} 
            filters={filters}
            onFilterChange={setFilters}
            selectedCategory={selectedCategory}
          />
          
          <div className="flex-grow">
            {!selectedCategory ? (
              <>
                <div className="text-center mb-12">
                  <h2 className="text-4xl font-black text-tech-gray uppercase italic tracking-tighter mb-4">
                    Nuestras <span className="text-forest-green">Categorías</span>
                  </h2>
                  <div className="h-1 w-24 bg-bright-yellow mx-auto" />
                </div>
                <CategoryGrid onSelectCategory={setSelectedCategory} />
              </>
            ) : (
              <>
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs font-bold text-tech-gray-light uppercase mb-2">
                      <button onClick={() => setSelectedCategory(null)} className="hover:text-forest-green">Inicio</button>
                      <span>/</span>
                      <span className="text-forest-green">{selectedCategory}</span>
                    </div>
                    <h2 className="text-3xl font-black text-tech-gray uppercase italic tracking-tighter">
                      {selectedCategory}
                    </h2>
                    <p className="text-tech-gray-light text-sm mt-1">Mostrando {filteredProducts.length} soluciones profesionales</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <select 
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="bg-white border border-gray-200 text-xs font-bold uppercase p-2 focus:outline-none focus:border-forest-green"
                    >
                      <option value="popular">Ordenar por: Popularidad</option>
                      <option value="price-asc">Precio: Menor a Mayor</option>
                      <option value="price-desc">Precio: Mayor a Menor</option>
                      <option value="newest">Novedades</option>
                    </select>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                  {filteredProducts.map(product => (
                    <div key={product.id}>
                      <ProductCard product={product} />
                    </div>
                  ))}
                </div>
                
                {filteredProducts.length === 0 && (
                  <div className="text-center py-24 bg-gray-50 rounded-sm border border-dashed border-gray-200">
                    <p className="text-tech-gray-light font-bold uppercase tracking-widest">No hay productos disponibles en esta categoría.</p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </main>
      <footer className="bg-tech-gray text-white pt-16 pb-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setSelectedCategory(null)}>
              <Zap className="text-bright-yellow w-6 h-6 fill-bright-yellow" />
              <span className="text-xl font-black tracking-tighter italic">LEDMANIA</span>
            </div>
            <p className="text-tech-gray-light text-sm leading-relaxed">
              Líder en soluciones LED industriales y sistemas de gestión energética inteligente. 
              Calidad certificada para instalaciones profesionales.
            </p>
          </div>
          
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest mb-6 text-bright-yellow">Navegación</h4>
            <ul className="space-y-3 text-sm text-tech-gray-light">
              <li><button onClick={() => setSelectedCategory(null)} className="hover:text-white transition-colors">Inicio</button></li>
              <li><a href="#" className="hover:text-white transition-colors">Fichas Técnicas</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Calculadora Energética</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Galería de Proyectos</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest mb-6 text-bright-yellow">Soporte</h4>
            <ul className="space-y-3 text-sm text-tech-gray-light">
              <li><a href="#" className="hover:text-white transition-colors">Guías de Instalación</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Políticas de Garantía</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Envíos y Devoluciones</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contacto Técnico</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-xs font-black uppercase tracking-widest mb-6 text-bright-yellow">Newsletter</h4>
            <p className="text-sm text-tech-gray-light mb-4">Recibe actualizaciones técnicas y lanzamientos.</p>
            <div className="flex">
              <input type="email" placeholder="Tu correo electrónico" className="bg-white/10 border-none p-2 text-sm flex-grow focus:ring-1 focus:ring-bright-yellow outline-none" />
              <button className="bg-bright-yellow text-black px-4 font-bold uppercase text-xs">Unirse</button>
            </div>
          </div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[10px] text-tech-gray-light uppercase tracking-widest">© 2026 LEDMANIA SOLUCIONES DE ENERGÍA INTELIGENTE. TODOS LOS DERECHOS RESERVADOS.</p>
          <div className="flex gap-6 text-[10px] text-tech-gray-light uppercase tracking-widest">
            <a href="#" className="hover:text-white">Privacidad</a>
            <a href="#" className="hover:text-white">Términos y Condiciones</a>
          </div>
        </div>
      </footer>
      
      <AIChatbot />
    </div>
  );
}
