export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  oldPrice?: number;
  image: string;
  lumens: number;
  wattage: number;
  ipRating: string;
  lightColor: 'Frío' | 'Cálido' | 'Neutro';
  shape?: string;
  size?: string;
  discount?: number;
  isNew?: boolean;
}

export interface FilterState {
  lumens: [number, number];
  wattage: [number, number];
  ipRatings: string[];
  priceRange: [number, number];
  lightColors: string[];
  shapes: string[];
  sizes: string[];
}
